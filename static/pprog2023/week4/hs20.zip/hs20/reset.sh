cp src/template/* src/solve/
sed "s/package template/package solve/g" src/template/Customer.java > src/solve/Customer.java
sed "s/package template/package solve/g" src/template/FoodTruck.java > src/solve/FoodTruck.java
