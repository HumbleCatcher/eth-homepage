package template;
import java.util.ArrayList;

public class FoodTruck extends Thread {

    private ArrayList<Customer> customersLine = new ArrayList<Customer>();

    private boolean mealReady = false;

    public void run() {
        while (true) {
            // wait if there are no customers or
            // the current meal has not been served
        	
        	// TODO

			// cook food for the next customer
			mealReady = true;

			// notify the next customer (only the next customer)
			
			// TODO
        }
    }
    
    public synchronized void addCustomer(Customer customer) {
        this.customersLine.add(customer);
        // TODO
    }    
    
    
    public synchronized void serveCustomer(Customer customer) {
        if (!isCustomersTurn(customer)) {
            System.out.println("Customer is trying to cut in line!");
            return;
        }

        removeCustomer(customer);
        this.mealReady = false;
        // TODO
    }
    
    private void removeCustomer(Customer customer) {
    	for (int i = 0; i < customersLine.size(); i++) {
			if (customersLine.get(i).equals(customer)) {
				customersLine.remove(i);
				return;
			}
    	}
	}

	public synchronized boolean isCustomersTurn(Customer customer) {
		if (!mealReady) {
			return false;
		}

		if (customersLine.isEmpty()) {
			return false;
		}

		return customersLine.get(0).equals(customer);
	}

}
