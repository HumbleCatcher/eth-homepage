package solution;
import java.util.ArrayList;

public class FoodTruck extends Thread {

    private ArrayList<Customer> customersLine = new ArrayList<Customer>();

    private boolean mealReady = false;

    public void run() {

        while (true) {
            // wait if there are no customers or
            // the current meal has not been served
            synchronized (this) {
                while (customersLine.isEmpty() || mealReady) {
                    try {
						wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
                }

				// cook food for the next customer
				mealReady = true;

				// notify the next customer (only the next customer)
				var next = customersLine.get(0);
				synchronized (next) {
					next.notify();
				}
            }

        }

    }
    
    public synchronized void addCustomer(Customer customer) {
        this.customersLine.add(customer);
        notify();
    }    
    
    
    public synchronized void serveCustomer(Customer customer) {
        if (!isCustomersTurn(customer)) {
            System.out.println("Customer is trying to cut in line!");
            return;
        }

        removeCustomer(customer);
        this.mealReady = false;
        notify();
    }
    
    private void removeCustomer(Customer customer) {
    	for (int i = 0; i < customersLine.size(); i++) {
			if (customersLine.get(i).equals(customer)) {
				customersLine.remove(i);
				return;
			}
    	}
	}

	public synchronized boolean isCustomersTurn(Customer customer) {
		if (!mealReady) {
			return false;
		}

		if (customersLine.isEmpty()) {
			return false;
		}

		return customersLine.get(0).equals(customer);
	}

}
