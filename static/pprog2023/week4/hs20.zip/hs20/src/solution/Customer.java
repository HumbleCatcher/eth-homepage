package solution;

public class Customer extends Thread {
    private final FoodTruck foodTruck;

    public Customer(FoodTruck foodTruck) {
        this.foodTruck = foodTruck;
    }



    public void run() {
        // Add this customer to the line
        foodTruck.addCustomer(this);

        // Wait until it is the customers turn
        synchronized (this) {
            while (!foodTruck.isCustomersTurn(this)) {
                try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }


        // Customer gets served
        foodTruck.serveCustomer(this);
    }
}