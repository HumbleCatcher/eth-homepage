package solve;

/*
 * Make sure that your solution is properly synchronized by using notify() , notifyAll() , wait() 
 * and the synchronized keyword where required, but **do not introduce unnecessary synchronization**.
 */

public class Customer extends Thread {
    private final FoodTruck foodTruck;

    public Customer(FoodTruck foodTruck) {
        this.foodTruck = foodTruck;
    }



    public void run() {
        // Add this customer to the line
        foodTruck.addCustomer(this);

        // Wait until it is the customers turn
		while (!foodTruck.isCustomersTurn(this)) {
			// TODO
		}

        // Customer gets served
        foodTruck.serveCustomer(this);
    }
}
