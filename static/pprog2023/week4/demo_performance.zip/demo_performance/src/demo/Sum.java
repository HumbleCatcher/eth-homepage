package demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Sum {

	/*
	 * After running the program, plots can be generated from `performance.csv` by running `python plot.py`
	 * (Warning: you will need to have matplotlib installed in python.)
	 */
	public static void main(String[] args) throws FileNotFoundException {
		
		// output is written to this file and read by `plot.py`
		var out = new PrintStream(new File("performance.csv"));
		
		final int nRuns = 10;
		
		/*
		 * Warning: It will take a while to run this with all the array lengths below.
		 */
//		for (int N : List.of(10_000, 100_000, 1_000_000, 10_000_000, 100_000_000)) {
		for (int N : List.of(100_000)) {
			System.out.format("N=%d:\n", N);
			for (int nThreads : List.of(2, 4, 8, 16, 32, 64)) {
				System.out.println(nThreads + " threads:");
				int[] data = genRandomNumbers(N);
				
				// try to warm up cache
				for (int i = 0; i < 5; i++) {
					computeSequential(data);
				}

				double averageDurationParallel = 0;
				for (int i = 0; i < nRuns; i++) {
					long start = System.nanoTime();
					computeParallel(data, nThreads);
					long duration = System.nanoTime() - start;
					averageDurationParallel += duration;
				}
				averageDurationParallel /= nRuns;
				printResult("Synchronized Parallel", averageDurationParallel);
				
				double averageDurationLock = 0;
				for (int i = 0; i < nRuns; i++) {
					long start = System.nanoTime();
					computeLockParallel(data, nThreads);
					long duration = System.nanoTime() - start;
					averageDurationLock += duration;
				}
				averageDurationLock /= nRuns;
				printResult("Lock Parallel", averageDurationLock);
				
				double averageDurationAtomic = 0;
				for (int i = 0; i < nRuns; i++) {
					long start = System.nanoTime();
					computeAtomicParallel(data, nThreads);
					long duration = System.nanoTime() - start;
					averageDurationAtomic += duration;
				}
				averageDurationAtomic /= nRuns;
				printResult("Atomic Parallel", averageDurationAtomic);
				
				
				System.out.println("How much faster is atomic vs. synchronized? " + ((double) averageDurationParallel / (double) averageDurationAtomic));
				System.out.println("How much faster is atomic vs. lock? " + ((double) averageDurationLock / (double) averageDurationAtomic));
				System.out.println();

				out.format("%d, %d, %d, %f, %f, %f\n", N, nThreads, nRuns, averageDurationParallel, averageDurationLock, averageDurationAtomic);
			}
		}
	}
	
	// The rest of the code is exactly like in demo3 from week 3.

	public static int computeSequential(final int[] data) {
		int value = 0;
		for (int v : data) {
			value += v;
		}
		return value;
	}
	
	public static int computeParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResult sumResult = new SumResult();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThread(data, sumResult, i * partitionSize, size);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				// Implements `t.join()` using `wait` and `notify`
				synchronized (t) {
					while (t.isAlive()) {
						/*
						 * Remember, this causes the CURRENT THREAD (i.e. the main thread) to wait, NOT the thread `t`.
						 */
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.value;
	}
	
	
	/*
	 * I did not show this in class, but it's interesting to compare its performance with the other solutions. It uses the 
	 * `ReentrantLock` class from Java, which (duhhh...) implements a reentrant lock.
	 */
	public static int computeLockParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResult sumResult = new SumResult();
		Lock lock = new ReentrantLock();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadLock(data, sumResult, i * partitionSize, size, lock);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				synchronized (t) {
					while (t.isAlive()) {
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.value;
	}
	
	
	public static int computeAtomicParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResult sumResult = new SumResult();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadAtomic(data, sumResult, i * partitionSize, size);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				synchronized (t) {
					while (t.isAlive()) {
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.atomicValue.get();
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, double durationNs) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + "ms on average");
	}
	
	

}

class SumThread extends Thread {
	private final int[] data;
	private SumResult result;
	private int start;
	private int length;

	public SumThread(final int[] data, SumResult result, int start, int length) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			/*
			 * Note: It would be way more efficient to collect the sum in a local variable and only then add to
			 * `result.value` in a `synchronized` block. I chose this inefficient implementation for demonstration purposes, since
			 * it actually becomes significantly harder to reproduce the bug of getting in incorrect result (due to threads adding their
			 * sums concurrently) with the more efficient implementation.
			 */
			synchronized (result) {
				result.value += data[i];
			}
		}

		/*
		 * Part of our custom `join` implementation: `notify` main thread when we are done.
		 */
		synchronized (this) {
			this.notify();
		}
	}
	
}


class SumThreadLock extends Thread {
	private final int[] data;
	private SumResult result;
	private int start;
	private int length;
	private Lock lock;

	public SumThreadLock(final int[] data, SumResult result, int start, int length, Lock lock) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			lock.lock();
			result.value += data[i];
			lock.unlock();
		
		}

		synchronized (this) {
			this.notify();
		}
	}
	
}


class SumThreadAtomic extends Thread {
	private final int[] data;
	private SumResult result;
	private int start;
	private int length;

	public SumThreadAtomic(final int[] data, SumResult result, int start, int length) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			result.atomicValue.addAndGet(data[i]);
		}
		
		
		synchronized (this) {
			this.notify();
		}
	}
	
}

class SumResult {
	public int value = 0;

	public AtomicInteger atomicValue = new AtomicInteger(0);
}