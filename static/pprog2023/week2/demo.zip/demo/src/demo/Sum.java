package demo;

import java.util.Random;

/*
 * Sums all values of a random array sequentially and using Java threads.
 */
public class Sum {
	static int N = 40_000_000;
	static int nThreads = 8;

	public static void main(String[] args) {
		/* 
		 * If you're confused why the durations output to the console seem some much less than the program 
		 * actually takes to run, it's because this step is slow.
		 */
		int[] data = genRandomNumbers(N);
		
		// TODO: implement sequential computation and measure duration
		int valueSequential = computeSequential(data);
		long durationSequential = 0;
		printResult("Sequential", durationSequential, valueSequential);

		// TODO: implement parallel computation and measure duration
		int valueParallel = computeParallel(data, nThreads);
		long durationParallel = 0;
		printResult("Parallel", durationParallel, valueParallel);
		
		// TODO: compute the speedup
		System.out.println("Speedup is " + 0);
	}

	public static int computeSequential(final int[] data) {
		// TODO: sum values in `data`
		return 0;
	}
	
	public static int computeParallel(final int[] data, int nThreads) {
		// TODO: compute size of partitions
		
		// TODO: initialize threads and pass them the right partitions
		
		// TODO: start threads and wait for them to finish
		
		// TODO: combine the results of the threads

		return 0;
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, long durationNs, int result) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + " ms and returned " + result);
	}
	
	

}

// TODO: write a class to perform the computation of a thread on a given partition of the `data`