package demo;

import java.util.Random;

public class Sum {
	static int N = 40_000_000;
	static int nThreads = 8;

	public static void main(String[] args) {
		/* 
		 * If you're confused why the times output to the console seem some much less than the program 
		 * actually takes to run, it's because this step is slow for some reason.
		 */
		int[] data = genRandomNumbers(N);
		
		long startSequential = System.nanoTime();
		int valueSequential = computeSequential(data);
		long durationSequential = System.nanoTime() - startSequential;
		printResult("Sequential", durationSequential, valueSequential);

		long startParallel = System.nanoTime();
		int valueParallel = computeParallel(data, nThreads);
		long durationParallel = System.nanoTime() - startParallel;
		printResult("Parallel", durationParallel, valueParallel);
		
		System.out.println("Speedup is " + ((double) durationSequential / (double) durationParallel));
	}

	public static int computeSequential(final int[] data) {
		int value = 0;
		for (int v : data) {
			value += v;
		}
		return value;
	}
	
	public static int computeParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		SumResult[] results = new SumResult[nThreads];
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			results[i] = new SumResult();
			threads[i] = new Thread(new SumThread(data, results[i], i * partitionSize, size));
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		int value = 0;
		for (var result : results) {
			value += result.value;
		}
		return value;
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, long durationNs, int result) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + " ms and returned " + result);
	}
	
	

}

class SumThread implements Runnable {
	private final int[] data;
	private SumResult result;
	private int start;
	private int length;

	public SumThread(final int[] data, SumResult result, int start, int length) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
	}

	@Override
	public void run() {
		int sum = 0;
		for (int i = start; i < start + length; i++) {
			sum += data[i];
		}
		result.value = sum;
	}
	
}

class SumResult {
	int value = 1;
}