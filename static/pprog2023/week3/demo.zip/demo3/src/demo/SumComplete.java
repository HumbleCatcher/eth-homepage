package demo;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SumComplete {
	static int N = 10_000_000;
	static int nThreads = 8;

	public static void main(String[] args) {
		int[] data = genRandomNumbers(N);
		
//		long startSequential = System.nanoTime();
//		int valueSequential = computeSequential(data);
//		long durationSequential = System.nanoTime() - startSequential;
//		printResult("Sequential", durationSequential, valueSequential);

		long startParallel = System.nanoTime();
		int valueParallel = computeParallel(data, nThreads);
		long durationParallel = System.nanoTime() - startParallel;
		printResult("Synchronized Parallel", durationParallel, valueParallel);
		
		long startLockParallel = System.nanoTime();
		int valueLockParallel = computeLockParallel(data, nThreads);
		long durationLockParallel = System.nanoTime() - startLockParallel;
		printResult("Lock Parallel", durationLockParallel, valueLockParallel);
		
		long startAtomicParallel = System.nanoTime();
		int valueAtomicParallel = computeAtomicParallel(data, nThreads);
		long durationAtomicParallel = System.nanoTime() - startAtomicParallel;
		printResult("Atomic Parallel", durationAtomicParallel, valueAtomicParallel);
		
		System.out.println();
		
//		System.out.println("Speedup is " + ((double) durationSequential / (double) durationParallel));

		System.out.println("How much faster is atomic vs. synchronized? " + ((double) durationParallel / (double) durationAtomicParallel));
		System.out.println("How much faster is atomic vs. lock? " + ((double) durationLockParallel / (double) durationAtomicParallel));
	}

	public static int computeSequential(final int[] data) {
		int value = 0;
		for (int v : data) {
			value += v;
		}
		return value;
	}
	
	public static int computeParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResultComplete sumResult = new SumResultComplete();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadComplete(data, sumResult, i * partitionSize, size);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				// Implements `t.join()` using `wait` and `notify`
				synchronized (t) {
					while (t.isAlive()) {
						/*
						 * Remember, this causes the CURRENT THREAD (i.e. the main thread) to wait, NOT the thread `t`.
						 */
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.value;
	}
	
	
	/*
	 * I did not show this in class, but it's interesting to compare its performance with the other solutions. It uses the 
	 * `ReentrantLock` class from Java, which (duhhh...) implements a reentrant lock.
	 */
	public static int computeLockParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResultComplete sumResult = new SumResultComplete();
		Lock lock = new ReentrantLock();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadLockComplete(data, sumResult, i * partitionSize, size, lock);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				synchronized (t) {
					while (t.isAlive()) {
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.value;
	}
	
	
	public static int computeAtomicParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResultComplete sumResult = new SumResultComplete();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadAtomicComplete(data, sumResult, i * partitionSize, size);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				synchronized (t) {
					while (t.isAlive()) {
						t.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.atomicValue.get();
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, long durationNs, int result) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + " ms and returned " + result);
	}
	
	

}

class SumThreadComplete extends Thread {
	private final int[] data;
	private SumResultComplete result;
	private int start;
	private int length;

	public SumThreadComplete(final int[] data, SumResultComplete result, int start, int length) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			/*
			 * Note: It would be way more efficient to collect the sum in a local variable and only then add to
			 * `result.value` in a `synchronized` block. I chose this inefficient implementation for demonstration purposes, since
			 * it actually becomes significantly harder to reproduce the bug of getting in incorrect result (due to threads adding their
			 * sums concurrently) with the more efficient implementation.
			 */
			synchronized (result) {
				result.value += data[i];
			}
		}

		/*
		 * Part of our custom `join` implementation: `notify` main thread when we are done.
		 */
		synchronized (this) {
			this.notify();
		}
	}
	
}


class SumThreadLockComplete extends Thread {
	private final int[] data;
	private SumResultComplete result;
	private int start;
	private int length;
	private Lock lock;

	public SumThreadLockComplete(final int[] data, SumResultComplete result, int start, int length, Lock lock) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			lock.lock();
			result.value += data[i];
			lock.unlock();
		
		}

		synchronized (this) {
			this.notify();
		}
	}
	
}


class SumThreadAtomicComplete extends Thread {
	private final int[] data;
	private SumResultComplete result;
	private int start;
	private int length;

	public SumThreadAtomicComplete(final int[] data, SumResultComplete result, int start, int length) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			result.atomicValue.addAndGet(data[i]);
		}
		
		
		synchronized (this) {
			this.notify();
		}
	}
	
}

class SumResultComplete {
	public int value = 0;

	public AtomicInteger atomicValue = new AtomicInteger(0);
}