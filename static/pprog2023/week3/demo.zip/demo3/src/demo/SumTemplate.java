package demo;

import java.util.Random;

public class SumTemplate {
	static int N = 4_000_000;
	static int nThreads = 8;

	public static void main(String[] args) {
		int[] data = genRandomNumbers(N);
		
		long startSequential = System.nanoTime();
		int valueSequential = computeSequential(data);
		long durationSequential = System.nanoTime() - startSequential;
		printResult("Sequential", durationSequential, valueSequential);

		long startParallel = System.nanoTime();
		int valueParallel = computeParallel(data, nThreads);
		long durationParallel = System.nanoTime() - startParallel;
		printResult("Parallel", durationParallel, valueParallel);
		
		System.out.println("Speedup is " + (double) durationSequential / (double) durationParallel);
	}

	public static int computeSequential(final int[] data) {
		int sum = 0;
		for (int i = 0; i < data.length; i++) {
			sum += data[i];
		}
		return sum;
	}
	
	public static int computeParallel(final int[] data, int nThreads) {
		int partitionSize = data.length / nThreads;

		SumResult[] results = new SumResult[nThreads];

		Thread[] threads = new Thread[nThreads];
		for (int i = 0; i < nThreads; i++) {
			int length = (i < nThreads - 1) ? partitionSize : partitionSize + data.length % nThreads;
			results[i] = new SumResult();
			threads[i] = new SumThread(data, results[i], i * partitionSize, length);
		}

		for (Thread t : threads) {
			t.start();
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		int sum = 0;
		for (var s : results) {
			sum += s.sum;
		}

		return sum;
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, long durationNs, int result) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + " ms and returned " + result);
	}
	
	

}

class SumThread extends Thread {
	private final int[] data;
	private int start;
	private int length;
	private SumResult result;

	public SumThread(final int[] data, SumResult result, int start, int length) {
		this.data = data;
		this.start = start;
		this.result = result;
		this.length = length;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			result.sum += data[i];
		}
	}
	
}

class SumResult {
	int sum = 0;
}
