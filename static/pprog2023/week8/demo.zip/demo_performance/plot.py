import csv
import sys

import matplotlib.pyplot as plt


def read_data(name):
    data = {}

    with open(name, "r") as file:
        reader = csv.reader(file)
        for line in reader:
            n, n_threads, n_runs, lock, custom_lock = line
            if n in data:
                data[n].append((n_threads, n_runs, lock, custom_lock))
            else:
                data[n] = [(n_threads, n_runs, lock, custom_lock)]

    return data


if __name__ == "__main__":
    file = "performance.csv"
    if len(sys.argv) > 1:
        file = sys.argv[1]
    data = read_data(file)

    for n, values in data.items():
        n_runs = values[0][1]
        n_threads = list(map(lambda t: int(t[0]), values))
        lock = list(map(lambda t: float(t[2]) / 10**6, values))
        custom_lock = list(map(lambda t: float(t[3]) / 10**6, values))
        plt.title(f"n = ${int(n):,}$")
        plt.xlabel("#threads")
        plt.ylabel(f"average duration over ${n_runs}$ runs (ms)")
        plt.plot(n_threads, lock, label="ReentrantLock")
        plt.plot(n_threads, custom_lock, label="CustomLock")
        plt.xticks(n_threads)
        plt.legend()
        plt.savefig(f"plots/n{n}nRuns{int(n_runs)}.svg")
        plt.clf()
