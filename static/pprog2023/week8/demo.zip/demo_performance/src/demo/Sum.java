package demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Sum {

	/*
	 * After running the program, plots can be generated from `performance.csv` by running `python plot.py`
	 * (Warning: you will need to have matplotlib installed in python.)
	 */
	public static void main(String[] args) throws FileNotFoundException {
		int[] data = genRandomNumbers(1000);
		
		System.out.println("Got " + computeLockParallel(data, 16, new ReentrantLock()) + " from ReentrantLock");
		System.out.println("Got " + computeLockParallel(data, 16, new CustomLock()) + " from CustomLock");

		benchmark();
	}
	
	public static void benchmark() throws FileNotFoundException {
		var out = new PrintStream(new File("performance.csv"));
		
		final int nRuns = 20;
		
		for (int N : List.of(10_000, 100_000, 1_000_000, 10_000_000)) {
//		for (int N : List.of(100_000)) {
			System.out.format("N=%d:\n", N);
			for (int nThreads : List.of(2, 4, 8, 16, 32, 64)) {
				System.out.println(nThreads + " threads:");
				int[] data = genRandomNumbers(N);
				
				// try to warm up cache
				for (int i = 0; i < 5; i++) {
					computeSequential(data);
				}
				
				double averageDurationLock = 0;
				for (int i = 0; i < nRuns; i++) {
					long start = System.nanoTime();
					computeLockParallel(data, nThreads, new ReentrantLock());
					long duration = System.nanoTime() - start;
					averageDurationLock += duration;
				}
				averageDurationLock /= nRuns;
				printResult("Lock Parallel", averageDurationLock);
				
				double averageDurationCustomLock = 0;
				for (int i = 0; i < nRuns; i++) {
					long start = System.nanoTime();
					computeLockParallel(data, nThreads, new CustomLock());
					long duration = System.nanoTime() - start;
					averageDurationCustomLock += duration;
				}
				averageDurationCustomLock /= nRuns;
				printResult("Custom Lock Parallel", averageDurationCustomLock);
				
				System.out.println("How much faster is lock vs. custom lock? " + ((double) averageDurationCustomLock / (double) averageDurationLock));
				System.out.println();

				out.format("%d, %d, %d, %f, %f\n", N, nThreads, nRuns, averageDurationLock, averageDurationCustomLock);
			}
		}
		
	}
	
	public static int computeSequential(final int[] data) {
		int value = 0;
		for (int v : data) {
			value += v;
		}
		return value;
	}
	
	public static int computeLockParallel(final int[] data, int nThreads, Lock lock) {
		int partitionSize = data.length / nThreads;
		Thread[] threads = new Thread[nThreads];
		
		SumResult sumResult = new SumResult();
		
		for (int i = 0; i < nThreads; i++) {
			int size = i < nThreads - 1 ? partitionSize : partitionSize + (data.length % nThreads);
			threads[i] = new SumThreadLock(data, sumResult, i * partitionSize, size, lock);
		}
		
		for (Thread t : threads) {
			t.start();
		}
		
		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return sumResult.value;
	}
	
	static int[] genRandomNumbers(int N) {
		Random rnd = new Random();
		int[] data = new int[N];
		for (int i = 0; i < N; i++) {
			data[i] = rnd.nextInt(10);
		}
		return data;
	}
	
	static void printResult(String name, double durationNs) {
		System.out.println(name + " took " + (durationNs / 1_000_000.0) + "ms on average");
	}
}


class SumThreadLock extends Thread {
	private final int[] data;
	private SumResult result;
	private int start;
	private int length;
	private Lock lock;

	public SumThreadLock(final int[] data, SumResult result, int start, int length, Lock lock) {
		this.data = data;
		this.result = result;
		this.start = start;
		this.length = length;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int i = start; i < start + length; i++) {
			lock.lock();
			result.value += data[i];
			lock.unlock();
		}
	}
	
}

class SumResult {
	public int value = 0;
}

class CustomLock implements Lock {
	AtomicBoolean locked = new AtomicBoolean(false);

	@Override
	public void lock() {
		while(!locked.compareAndSet(false, true));
	}
	
	
	@Override
	public void unlock() {
		locked.set(false);
	}


	@Override
	public void lockInterruptibly() throws InterruptedException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean tryLock() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Condition newCondition() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
